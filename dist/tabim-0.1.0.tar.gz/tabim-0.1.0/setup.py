# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['tabim']

package_data = \
{'': ['*']}

install_requires = \
['attrs>=21.2.0,<22.0.0',
 'more-itertools>=8.8.0,<9.0.0',
 'pyguitarpro>=0.8,<0.9',
 'typer>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['tabim = tabim.main:main']}

setup_kwargs = {
    'name': 'tabim',
    'version': '0.1.0',
    'description': 'Guitar Pro to ASCII Tab converter',
    'long_description': None,
    'author': 'Tamir Bahar',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
